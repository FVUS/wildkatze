#include "MaxGBCA.h"

MaxGBCA::
MaxGBCA()
:     _sharpness    (3.5)
,     _AdotDY       (1)
,     _angleWtFactor(1.0)
,     _AFact        (1.0)
,     _angleFac     (0.05)
{

}

MaxGBCA::
~MaxGBCA()
{
}


