
#ifndef SRC_ZALESAKDISC_H_
#define SRC_ZALESAKDISC_H_

#include "BaseSolver.h"

class ZalesakDisc  :  public BaseSolver
{
public:
           ZalesakDisc();
  virtual ~ZalesakDisc();

  void     initialize    (double u0, double v0);
  void     applyBC       (   );


};

#endif
