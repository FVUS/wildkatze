
#ifndef SRC_CVFACES_H_
#define SRC_CVFACES_H_


#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <cmath>

class CvFaces
{
public:
  CvFaces();
  virtual ~CvFaces();

  int                      _FaceType;

  // area vector
  std::vector < double >       _Amag;

  std::vector < double >         _Ax;
  std::vector < double >         _Ay;
  std::vector < double >         _Az;

  // face centers
  std::vector < double >         _fx;
  std::vector < double >         _fy;
  std::vector < double >         _fz;

  std::vector < int >            _CL;
  std::vector < int >            _CR;

  std::vector < int >     _indexLeft;
  std::vector < int >    _indexRight;


};

#endif
