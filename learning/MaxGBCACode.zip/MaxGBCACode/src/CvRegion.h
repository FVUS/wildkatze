
#ifndef SRC_CVREGION_H_
#define SRC_CVREGION_H_

#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <cmath>

#include "CvFaces.h"
#include "Matrix.h"


class CvRegion
{
public:
  CvRegion();
  virtual ~CvRegion();

  void     createRegion          ( double xmin, double xmax, double ymin, double ymax, int xdiv, int ydiv  );
  void     createRegionMatrix    ();

  void     interpolateToNodes    ( std::vector<double>& cellD, std::vector<double>& nodeD);


  int                          _ncells;
  int                       _ncellsBnd;

  int                     _xdiv, _ydiv;

  //  0 is boundary and 1 is live
  std::vector < int >         cellType;
  std::vector < int >          cellIds;


  std::vector < CvFaces >     _cvFaces;

  // cell centers
  std::vector < double >           _xc;
  std::vector < double >           _yc;
  std::vector < double >           _zc;

  std::vector < double >       _volume;

  Matrix                       _matrix;

  std::vector < int >         _nodeIds;
  std::vector < double >           _xn;
  std::vector < double >           _yn;
  std::vector < double >           _zn;

  // we can use this as graph data structure too
  Matrix                 _cellsForNode;

};

#endif
