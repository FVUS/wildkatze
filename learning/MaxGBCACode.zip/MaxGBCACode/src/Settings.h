
#ifndef SRC_SETTINGS_H_
#define SRC_SETTINGS_H_

#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <cmath>
#include <fstream>
#include <map>

class Settings
{
public:
           Settings();
  virtual ~Settings();

  void          load(  std::string fname );

  std::string   getStringValue(   std::string  str );
  double        getRealValue  (   std::string  str );

  // settings
  std::map < std::string , double       >     _settings;
  std::map < std::string , std::string  >     _settingsStrings;

};

#endif
