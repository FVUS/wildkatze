
#include <iostream>
// #include "TestSolver.h"
#include "DiscSolver.h"
#include "ZalesakDisc.h"

#include "SchemeTestSolver.h"

#include "Settings.h"


int main(int argc, char *argv[])
{

  Settings  settings;

  settings.load( argv[1] );



  if ( settings. getStringValue("problem")  ==  "disc-advection" )
  {
    DiscSolver  baseSolver;

    baseSolver .  setSettings( &settings );

    baseSolver .  createRegion  ( 0.0, 6.0,  0.0, 4.0,  300, 200 );

    baseSolver .  initialize    ( settings. getRealValue("disc-advection-x-velocity"), settings. getRealValue("disc-advection-y-velocity") );

    baseSolver .  solve       ( settings. getRealValue("max-time"), settings. getRealValue("inner-iterations"),  settings. getRealValue("courant")  );

    std::string  fname =  (  settings. getStringValue("problem") + "_Courant" + std::to_string( settings. getRealValue("courant")) );


    fname    =   fname  + "_xvel"  +  std::to_string( settings. getRealValue("disc-advection-x-velocity")) ;
    fname    =   fname  + "_yvel"  +  std::to_string( settings. getRealValue("disc-advection-y-velocity")) ;


    fname    =   fname  + "_"  +  settings. getStringValue("convection-scheme");

    baseSolver .  exportResults(  fname );
  }


  if (  settings. getStringValue("problem")  ==  "zalesak-disc" )
  {
    ZalesakDisc  baseSolver;

    baseSolver .  setSettings( &settings );

    baseSolver .  createRegion  ( 0.0, 1.0,  0.0, 1.0,  100, 100 );

    baseSolver .  initialize    ( 0.0, 0.0 );


    baseSolver .  solve       ( settings. getRealValue("max-time"), settings. getRealValue("inner-iterations"),  settings. getRealValue("courant")  );

    std::string  fname =  (  settings. getStringValue("problem") + "_Courant" + std::to_string( settings. getRealValue("courant")) );


    fname    =   fname  + "_xvel"  +  std::to_string( settings. getRealValue("disc-advection-x-velocity")) ;
    fname    =   fname  + "_yvel"  +  std::to_string( settings. getRealValue("disc-advection-y-velocity")) ;


    fname    =   fname  + "_"  +  settings. getStringValue("convection-scheme");
    baseSolver .  exportResults( fname );
  }




  if ( settings. getStringValue("problem")  ==  "scalar-advection" )
  {
      SchemeTestSolver  baseSolver;

    baseSolver .  setSettings( &settings );

    baseSolver .  createRegion  ( 0.0, 0.1,  0.0, 0.1,  50, 50 );

    baseSolver .  initialize    ( settings. getRealValue("disc-advection-x-velocity"), settings. getRealValue("disc-advection-y-velocity") );

    baseSolver .  solve         ( settings. getRealValue("max-time"), settings. getRealValue("inner-iterations"),  settings. getRealValue("courant")  );

    std::string  fname =        (  settings. getStringValue("problem") + "_Courant" + std::to_string( settings. getRealValue("courant")) );


    fname    =   fname  + "_xvel"  +  std::to_string( settings. getRealValue("disc-advection-x-velocity")) ;
    fname    =   fname  + "_yvel"  +  std::to_string( settings. getRealValue("disc-advection-y-velocity")) ;


    fname    =   fname  + "_"  +  settings. getStringValue("convection-scheme");

    baseSolver .  exportResults(  fname );
  }

 
  return 0;
}
