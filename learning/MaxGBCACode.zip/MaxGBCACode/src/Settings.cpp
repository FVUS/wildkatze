
#include "Settings.h"

Settings::
Settings()
{

}

Settings::
~Settings()
{
}

void
Settings::
load(std::string fname)
{
  std::fstream infile;
  infile.open(fname);

  std::cout << " \tReading settings."   << std::endl << std::endl;


  int    nstr;
  infile >> nstr ;

  for (int i = 0; i < nstr; i++)
    {
      std::string nm;
      std::string val;

      infile >>  nm;
      infile >>  val;

      _settingsStrings[ nm ]   =   val;

      std::cout << " \t" <<  nm << " \t" << val << std::endl;

    }


  int    nvals;
  infile >> nvals ;

  for (int i = 0; i < nvals; i++)
    {
      std::string nm;
      double     val;

      infile >>  nm;
      infile >>  val;

      _settings[ nm ]   =   val;
      std::cout << " \t" <<  nm << " \t" << val << std::endl;

    }


  std::cout   << std::endl;

  infile.close();
}

std::string
Settings::
getStringValue(std::string str)
{

  return _settingsStrings.at( str );

}

double
Settings::
getRealValue(std::string str)
{
  return _settings.at( str );
}
