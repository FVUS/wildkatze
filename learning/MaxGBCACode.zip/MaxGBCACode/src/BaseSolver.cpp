
#include "BaseSolver.h"
#include "MaxGBCA.h"
#include "HRIC.h"
#include "CICSAM.h"


BaseSolver::
BaseSolver              ()
:              _settings(0)
,             _currTime0(0)
,           _currTimeNow(0)
,              _currTime(0)
,  _currentTimeIteration(0)
, _currentInnerIteration(0)
,     _maxInnerIteration(0)
,               _maindt0(0)
,               _maindt1(0)
,               _maindt2(0)
,           _isTransient(true)
,                   _urf(0.999)

{
}

BaseSolver::
~BaseSolver()
{
}

void
BaseSolver::
createRegion(double xmin, double xmax, double ymin, double ymax, int xdiv, int ydiv)
{
  _region   .   createRegion ( xmin,  xmax,     ymin,  ymax,      xdiv,  ydiv );
}



void
BaseSolver::
solve(double tmax, int innerItrs, double Courant)
{
  double dt               =        1.0E-4;
  double t                =        0;

  _currTime               =        0;
  _currTime0              =        0;

  dt                      =        adjustTimeStep(Courant, dt, 1E-7, 10 );

  double dtSaved          =        dt;

  _currentTimeIteration   =        0;

  while ( t < tmax )
    {
      if (_currentTimeIteration < 4)
        {
          dt         =       0.25 * dtSaved;
        }
      else
        {
          dt         =       dtSaved;
        }

      _currTime0     =      _currTime;
      _currTimeNow   =      _currTime0;

      t             +=       dt;
      _currTime      =       t;

      std::cout << " Time  =  \t" << t  << ", dt =  \t" << dt << std::endl;

      _maindt0       =       dt;

      timeStep               ( t,   dt , innerItrs );

      _currentTimeIteration++;
    }

}

void
BaseSolver::
exportResults(std::string baseN)
{

  std::string fname;

  fname =  baseN + ".vtk";

  FILE *outfile;

  if ((outfile = fopen(fname.c_str(), "w")) == NULL)
    {
      printf("Failed to open File \n");
    }
  else
    {
      fprintf(outfile, "# vtk DataFile Version 2.0\n");
      fprintf(outfile, "Test VOF Program\n");
      fprintf(outfile, "ASCII\n");
      fprintf(outfile, "DATASET POLYDATA\n");
      fprintf(outfile, "POINTS %d float\n", (int) _region._xn.size() );

      for (int i = 0; i < _region._xn.size(); i++)
        {
          fprintf(outfile, "%2.8le %2.8le  %2.8le\n", _region._xn[i], _region._yn[i], _region._zn[i]);
        }

      int  total_poly     =      _region._ncells;
      int  xdiv           =      _region._xdiv;
      int  ydiv           =      _region._ydiv;
      int const  Nj       =       ydiv+2;


      fprintf(outfile, "POLYGONS %d %d\n", total_poly, total_poly * 5);

      for (int i = 1; i <=  xdiv ; i++)
        {
          for (int j = 1; j <=  ydiv ; j++)
            {
              // each cell has four nodes
              int const cid      =      _region.cellIds [i*Nj + j]   - 1;

              fprintf ( outfile, "%d ", 4 );

              // cv faces cells
              {
                int ib           =       i-1;
                int jb           =       j-1;

                int nid          =      _region. _nodeIds[ ib * (ydiv+1) + jb];

                fprintf ( outfile, " %d", nid );
              }

              {
                int ib           =      i;
                int jb           =      j-1;

                int nid          =     _region._nodeIds[ ib * (ydiv+1) + jb];

                fprintf ( outfile, " %d", nid );

              }

              {
                int ib           =      i;
                int jb           =      j;

                int nid          =     _region._nodeIds[ ib * (ydiv+1) + jb];

                fprintf( outfile, " %d", nid );

              }

              {
                int ib           =      i-1;
                int jb           =      j;

                int nid          =     _region._nodeIds[ ib * (ydiv+1) + jb];

                fprintf( outfile, " %d", nid );
              }

              fprintf  ( outfile, " \n" );
            }
        }


      // scalars
      fprintf ( outfile, "POINT_DATA  %d\n", (int) ( _region._xn.size() ) );

      std::vector  <double>               nodeD;

      nodeD  .   resize(  _region._xn.size()  );

      {
        _region    .   interpolateToNodes ( _alpha0,  nodeD       );

        std::string    vname              ( "alpha-0"             );

        fprintf  ( outfile, "SCALARS  %s float\n", vname.c_str()  );
        fprintf  ( outfile, "LOOKUP_TABLE default\n"              );

        for ( int k = 0; k < _region._xn.size(); k++ )
          {
            fprintf  ( outfile, "%g\n",  nodeD[k]    );
          }
      }

      {
        _region    .   interpolateToNodes ( _alphaInit,  nodeD    );

        std::string    vname              ( "alpha-0-init"        );

        fprintf  ( outfile, "SCALARS  %s float\n", vname.c_str()  );
        fprintf  ( outfile, "LOOKUP_TABLE default\n"              );

        for ( int k = 0; k < _region._xn.size(); k++ )
          {
            fprintf(outfile, "%g\n",  nodeD[k] );
          }
      }

      std::vector<double> nodeUx;
      std::vector<double> nodeUy;
      std::vector<double> nodeUz;

      nodeUx  .  resize( _region._xn.size() );
      nodeUy  .  resize( _region._xn.size() );
      nodeUz  .  resize( _region._xn.size() );

      {
        _region  .  interpolateToNodes( _xvel,  nodeUx);
        _region  .  interpolateToNodes( _yvel,  nodeUy);
        _region  .  interpolateToNodes( _zvel,  nodeUz);

        std::string vname             ( "velocity"    ) ;

        fprintf(outfile, "VECTORS  %s float\n", vname.c_str()  );

        for ( int k = 0; k < _region._xn.size(); k++ )
          {
            fprintf  ( outfile, "%g %g %g\n",  nodeUx[k], nodeUy[k], nodeUz[k] );
          }
      }

      fclose ( outfile );
    }

}





double
BaseSolver::
adjustTimeStep( double _cmax, double _currDeltaT, double _delTMin, double _delTMax )
{
  double       dt        =     0.1;
  bool         transient =     false;

  _currDeltaT     =     _delTMax;

  std::vector < CvFaces >  &  cvFaces  (  _region._cvFaces );

  std::vector < double > & xc (  _region._xc );
  std::vector < double > & yc (  _region._yc );
  std::vector < double > & zc (  _region._zc );

  std::vector < double > & xVel ( _xvel );
  std::vector < double > & yVel ( _yvel );
  std::vector < double > & zVel ( _zvel );


  //for (int b = 0; b < cvFaces.size(); b++)
    {
      // using only interior
      int b  =  0;
      CvFaces  & faces( cvFaces[b] );

      std::vector < double > & ax (  faces._Ax );
      std::vector < double > & ay (  faces._Ay );
      std::vector < double > & az (  faces._Az );

      std::vector < double > & xf (  faces._fx );
      std::vector < double > & yf (  faces._fy );
      std::vector < double > & zf (  faces._fz );


      for (int f = 0; f < faces._CL.size(); f++)
        {
          int  const  cl   =   faces._CL[f];
          int  const  cr   =   faces._CR[f];


          const double dist0 =     std::sqrt( (xf[f]-xc[cl])*(xf[f]-xc[cl]) + (yf[f]-yc[cl])*(yf[f]-yc[cl]) + (zf[f]-zc[cl])*(zf[f]-zc[cl]) );
          const double dist1 =     std::sqrt( (xf[f]-xc[cr])*(xf[f]-xc[cr]) + (yf[f]-yc[cr])*(yf[f]-yc[cr]) + (zf[f]-zc[cr])*(zf[f]-zc[cr]) );

          const double    dm =     (dist0 < dist1) ? dist0 + 1.0E-16 : dist1 + 1.0E-16;


          double UatFace  =     0.5 * (xVel[cl] + xVel[cr]);
          double VatFace  =     0.5 * (yVel[cl] + yVel[cr]);
          double WatFace  =     0.5 * (zVel[cl] + zVel[cr]);

          double arX      =     ax[f];
          double arY      =     ay[f];
          double arZ      =     az[f];

          double areaFace =     std::sqrt(arX * arX + arY * arY + arZ * arZ);

          double t_xc     =     xc[cl];
          double t_yc     =     yc[cl];
          double t_zc     =     zc[cl];
          double h_xc     =     xc[cr];
          double h_yc     =     yc[cr];
          double h_zc     =     zc[cr];

          double distCenterToCenter =  2.0*dm;

          double vdotA    =     (UatFace * arX + VatFace * arY + WatFace * arZ);

          double       delTface  =   _delTMax;

          if ( std::fabs(vdotA) > 1E-20)
            {
              delTface = (distCenterToCenter * _cmax)
                         / std::sqrt(UatFace * UatFace + VatFace * VatFace + WatFace * WatFace + 1.0E-20);

               if (_currDeltaT > delTface)
                {
                  _currDeltaT = delTface;
                }
            }

        }
    }


  if (_currDeltaT  <    _delTMin)
    _currDeltaT    =    _delTMin;


  if (_currDeltaT  >    _delTMax)
    _currDeltaT    =    _delTMax;


  std::cout << " Time step change      :: " << dt << "  ----------------->  " << _currDeltaT << std::endl;


  return _currDeltaT;

}


void
BaseSolver::
timeStep(double time_, double dt, int innerItrs)
{
  // takes a single step of VOF solver

  memcpy(  _alpha02.data(), _alpha01.data(), sizeof(double) * _alpha0.size()  );
  memcpy(  _alpha01.data(), _alpha0.data(),  sizeof(double) * _alpha0.size()  );


  memcpy(  _alpha12.data(), _alpha11.data(), sizeof(double) * _alpha1.size()  );
  memcpy(  _alpha11.data(), _alpha1.data(),  sizeof(double) * _alpha1.size()  );

  preSolveUpdate(  time_ ,  dt );


  for (int itr =  0; itr < innerItrs; itr++)
    {
      _currentInnerIteration    =     itr;
      _maxInnerIteration        =     innerItrs;

      preprocessSubIteration    ();

      applyBC           ();

      calcMinMax        ( _alpha0, _alpha0Min,  _alpha0Max             );
      gradient          ( _alpha0, _dAlphadx0,  _dAlphady0, _dAlphadz0 );

      _region._matrix   .    clearMatrix();

      std::memset       (  _Ap .data(), 0 , sizeof(double) * _Ap .size()  );
      std::memset       (  _Src.data(), 0 , sizeof(double) * _Src.size()  );

      if (_isTransient)
          unsteadyTerm      ();


      convectionTerm    ( dt );
      applyUrf          ( _urf );

      // solve the system
      _region._matrix   .    solve( 10 , 1.0E-15 );

      acquireCorrection ( 1.0 );


      applyBC           ();

      postProcessSubIteration();
    }



}



void
BaseSolver::
preprocessSubIteration(   )
{
  _currTimeNow    =   _currTime0  +  _maindt0;
}

void
BaseSolver::
postProcessSubIteration()
{
  _maindt2  =  _maindt1;
  _maindt1  =  _maindt0;
}





void
BaseSolver::
calcMinMax(std::vector<double>& alpha, std::vector<double>& alphaMin,     std::vector<double>& alphaMax)
{

  for (int c = 0; c < alpha.size(); c++)
    {
      alphaMin[c]       =    alpha[c];
      alphaMax[c]       =    alpha[c];
    }

  std::vector < CvFaces >  &  cvFaces  (  _region._cvFaces );

  for (int b = 0; b < cvFaces.size(); b++)
    {
      CvFaces  & faces( cvFaces[b] );

      for (int f = 0; f < faces._CL.size(); f++)
        {
          int  const  cl   =   faces._CL[f];
          int  const  cr   =   faces._CR[f];

          if (  alphaMin[cl] >  alpha[cr] )    alphaMin[cl] =  alpha[cr];
          if (  alphaMax[cl] <  alpha[cr] )    alphaMax[cl] =  alpha[cr];

          if (  alphaMin[cr] >  alpha[cl] )    alphaMin[cr] =  alpha[cl];
          if (  alphaMax[cr] <  alpha[cl] )    alphaMax[cr] =  alpha[cl];
        }
    }



}

void
BaseSolver::
gradient(std::vector<double>& alpha, std::vector<double>& alphadx,  std::vector<double>& alphady, std::vector<double>& alphadz)
{
  std::memset(  alphadx.data(), 0 , sizeof(double) * alphadx.size()  );
  std::memset(  alphady.data(), 0 , sizeof(double) * alphady.size()  );
  std::memset(  alphadz.data(), 0 , sizeof(double) * alphadz.size()  );

  std::vector < CvFaces >  &  cvFaces  (  _region._cvFaces );

  for (int b = 0; b < cvFaces.size(); b++)
    {
      CvFaces  & faces( cvFaces[b] );

      std::vector < double > & ax (  faces._Ax );
      std::vector < double > & ay (  faces._Ay );
      std::vector < double > & az (  faces._Az );

      for (int f = 0; f < faces._CL.size(); f++)
        {
          int  const  cl    =    faces._CL[f];
          int  const  cr    =    faces._CR[f];
          double
          uf                =    0.5*( alpha[cl] + alpha[cr] );

          alphadx[ cl ]    +=    (uf * ax[ f ])  ;
          alphady[ cl ]    +=    (uf * ay[ f ])  ;
          alphadz[ cl ]    +=    (uf * az[ f ])  ;

          alphadx[ cr ]    -=    (uf * ax[ f ])  ;
          alphady[ cr ]    -=    (uf * ay[ f ])  ;
          alphadz[ cr ]    -=    (uf * az[ f ])  ;
        }
    }


  int ncells    =   _region._ncells;
  int nbcells   =   _region._ncellsBnd;

  for (int c = 0; c < ncells; c++)
    {
      alphadx[ c ]    /=   _region._volume[c];
      alphady[ c ]    /=   _region._volume[c];
      alphadz[ c ]    /=   _region._volume[c];
    }


  for (int c = ncells; c < nbcells; c++)
    {
      alphadx[ c ]     =   0;
      alphady[ c ]     =   0;
      alphadz[ c ]     =   0;
    }

}




void
BaseSolver::
unsteadyTerm(   )
{
  double dt0 =  _maindt0;
  double dt1 =  _maindt1;
  double dt2 =  _maindt2;

  int ncells    =   _region._ncells;

  double const _alpha                =      (dt1/dt0)  + 1.0 ;
  double const _beta                 =      _alpha* _alpha - 1;
  double const _denom                =      _alpha*(_alpha - 1)*dt0;

  bool        isEuler                =      ( _currentTimeIteration < 2)  ?  true  : false;

  if (_settings)
    {
      if (  _settings->getStringValue( "time-scheme")  ==  "Euler")
        {
          isEuler  =   true;
        }
    }

  if (isEuler)
    {
      for (int c = 0; c < ncells; c++)
        {
          double const vol      =        _region._volume[c];
          double const daldt    =      ( _alpha0[c] -   _alpha01[c])/dt0;
          double const ap       =         1.0 / dt0 ;

          _Src[c]              -=         vol * daldt;
          _Ap [c]              +=         vol * ap;
        }
    }
  else
    {
      for (int c = 0; c < ncells; c++)
        {
          double const vol     =      _region._volume[c];

          double daldt         =       (_beta*( _alpha0[c] -   _alpha01[c]) + ( _alpha02[c] -  _alpha01[c]))/(_denom);
          double ap            =       (_beta )/(_denom);

          _Src[c]             -=        vol * daldt;
          _Ap [c]             +=        vol * ap;

        }
    }



}





void
BaseSolver::
convectionTerm(double dt)
{

  double     _alphaRange(1.0);
  double     _sharpness (3.5);
  double     k_         (0.55);
  double     _CflLower(0.6);
  double     _CflUpper(1.25);
  double     _angleFac(0.05);
  double     _downwindSharpening0(  5.0E-2 );
  double     _downwindSharpening ( 15.0E-2 );

  _downwindSharpening   =   std::max(   _downwindSharpening ,  0.06 );
  _downwindSharpening0  =  _downwindSharpening/3.0;

  double const CflDifference   =     _CflUpper - _CflLower;

  double  a1 = ( 2.0/0.30);
  double  a2 = (-1.0/0.09);
  double     const flxLimiter0 =  1;
  double     const flxLimiter1 =  1;


  std::vector < CvFaces >  &  cvFaces  (  _region._cvFaces );

  bool transient  =  true;

  std::vector < double > & xc (  _region._xc );
  std::vector < double > & yc (  _region._yc );
  std::vector < double > & zc (  _region._zc );
  std::vector < double > & vol (  _region._volume );

  std::vector < double > & xVel ( _xvel );
  std::vector < double > & yVel ( _yvel );
  std::vector < double > & zVel ( _zvel );

  int   schemeVal   =   0;

  if (_settings)
    {
      if (  _settings->getStringValue( "convection-scheme")  ==  "HRIC")
        {
          schemeVal  =   1;
        }

      if (  _settings->getStringValue( "convection-scheme")  ==  "CICSAM")
        {
          schemeVal  =   2;
        }

      if (  _settings->getStringValue( "convection-scheme")  ==  "Core")
        {
          schemeVal  =   3;
        }

      if (  _settings->getStringValue( "convection-scheme")  ==  "Core-limited")
        {
          schemeVal  =   4;
        }

      if (  _settings->getStringValue( "convection-scheme")  ==  "MaxGBCA")
        {
          schemeVal  =   5;
        }


    }

  MaxGBCA        maxGb;

  for (int b = 0; b < cvFaces.size(); b++)
    {
      CvFaces  & faces( cvFaces[b] );

      std::vector < double > & ax (  faces._Ax );
      std::vector < double > & ay (  faces._Ay );
      std::vector < double > & az (  faces._Az );


      std::vector < double > & xf (  faces._fx );
      std::vector < double > & yf (  faces._fy );
      std::vector < double > & zf (  faces._fz );


      std::vector < int > & CLIndex ( faces . _indexLeft );
      std::vector < int > & CRIndex ( faces . _indexRight );

      double * Ax  =  _region._matrix.getAx   ();

      if (CLIndex.size() > 0 )
        {
          // interior
          for (int f = 0; f < faces._CL.size(); f++)
            {
              int  const  cl   =   faces._CL[f];
              int  const  cr   =   faces._CR[f];

              double
              mdot            =        ax[ f ] * 0.5 * (_xvel[cl] + _xvel[cr]) + ay[ f ] * 0.5 * (_yvel[cl] + _yvel[cr])  + az[ f ] * 0.5 * (_zvel[cl] + _zvel[cr]);

              if (mdot >= 0)
                {
                  _Ap[cl]          += mdot;
                  Ax[ CRIndex[f] ] -= mdot;
                  _Ap[cr]          += mdot;
                }
              else
                {
                  _Ap[cr]          -= mdot;
                  Ax[ CLIndex[f] ] += mdot;
                  _Ap[cl]          -= mdot;
                }


              double varf     =        ( mdot >= 0 ) ?  _alpha0[cl]  :  _alpha0[cr];


              int    u, d;
              double flagUpwind;

              if ( mdot  > 0)
                {
                  u       =     cl;
                  d       =     cr;
                  flagUpwind    =     1;
                }
              else
                {
                  u       =     cr;
                  d       =     cl;
                  flagUpwind    =     -1;
                }

             double YminGlob =  ( _alpha0Min[cl] < _alpha0Min[cr] ) ? _alpha0Min[cl] : _alpha0Min[cr];
             double YmaxGlob =  ( _alpha0Max[cl] > _alpha0Max[cr] ) ? _alpha0Max[cl] : _alpha0Max[cr];

              double Yu   =     _alpha0[u];
              double Yd   =     _alpha0[d];


              if (schemeVal == 1 )
                {
                  varf       =    HRIC(
                                                           transient,   dt,  vol[u]
                                                       ,    _CflLower,   _CflUpper,   a1,   a2
                                                       ,   xf[f],   yf[f],   zf[f]
                                                       ,   ax[f],   ay[f],   az[f]
                                                       ,   xc[u],  yc[u],  zc[u]
                                                       ,   xc[d],  yc[d],  zc[d]
                                                       ,  mdot, Yu, Yd
                                                       ,  _dAlphadx0[u] , _dAlphady0[u] , _dAlphadz0[u]
                                                       ,  _dAlphadx0[d] , _dAlphady0[d] , _dAlphadz0[d]
                                                       ,   xVel[u] ,  yVel[u],  zVel[u]
                                                       ,   _downwindSharpening,  _downwindSharpening0
                                                       ,   YminGlob,  YmaxGlob
                                                       ,       _angleFac
                                                      );

                }
              else if (schemeVal == 2 )
                {
                  varf       =     CICSAM(      dt, vol[cl], vol[cr]
                                            ,   xf[f],   yf[f],   zf[f]
                                            ,   ax[f],   ay[f],   az[f]
                                            ,   xc[cl],  yc[cl],  zc[cl]
                                            ,   xc[cr],  yc[cr],  zc[cr]
                                            ,  _alpha0[cl], _alpha0[cr]
                                            ,  _dAlphadx0[cl] , _dAlphady0[cl] , _dAlphadz0[cl]
                                            ,  _dAlphadx0[cr] , _dAlphady0[cr] , _dAlphadz0[cr]
                                            ,    mdot
                                            ,   xVel[cl] ,  yVel[cl],  zVel[cl]
                                            ,   xVel[cr] ,  yVel[cr],  zVel[cr]

                                              );

                }
              else if (schemeVal == 3 )
                {
                  varf               =     maxGb . faceFractionS(   "core"
                                                                    ,   xf[f],   yf[f],   zf[f]
                                                                    ,   ax[f],   ay[f],   az[f]
                                                                    ,   xc[u],  yc[u],  zc[u]
                                                                    ,   xc[d],  yc[d],  zc[d]
                                                                    ,  mdot, Yu, Yd
                                                                    ,  _dAlphadx0[u] , _dAlphady0[u] , _dAlphadz0[u]
                                                                    ,  _dAlphadx0[d] , _dAlphady0[d] , _dAlphadz0[d]
                                                                    ,   xVel[u] ,  yVel[u],  zVel[u]
                                                         );

                }
              else if (schemeVal == 4 )
                {
                  varf               =     maxGb . faceFractionS(   "core-limited"
                                                                    ,   xf[f],   yf[f],   zf[f]
                                                                    ,   ax[f],   ay[f],   az[f]
                                                                    ,   xc[u],  yc[u],  zc[u]
                                                                    ,   xc[d],  yc[d],  zc[d]
                                                                    ,  mdot, Yu, Yd
                                                                    ,  _dAlphadx0[u] , _dAlphady0[u] , _dAlphadz0[u]
                                                                    ,  _dAlphadx0[d] , _dAlphady0[d] , _dAlphadz0[d]
                                                                    ,   xVel[u] ,  yVel[u],  zVel[u]
                                                         );

                }
              else if (schemeVal == 5 )
                {
                  varf               =     maxGb . faceFractionS(   "maxgbca"
                                                                    ,   xf[f],   yf[f],   zf[f]
                                                                    ,   ax[f],   ay[f],   az[f]
                                                                    ,   xc[u],  yc[u],  zc[u]
                                                                    ,   xc[d],  yc[d],  zc[d]
                                                                    ,  mdot, Yu, Yd
                                                                    ,  _dAlphadx0[u] , _dAlphady0[u] , _dAlphadz0[u]
                                                                    ,  _dAlphadx0[d] , _dAlphady0[d] , _dAlphadz0[d]
                                                                    ,   xVel[u] ,  yVel[u],  zVel[u]
                                                         );

                }



              if (varf < 0.0             )  varf  =  0;
              if (varf > 1.0             )  varf  =  1.0;

              // the flux
              double mflux   =  mdot * varf;
              _Src[cl]       -=        mflux ;
              _Src[cr]       +=        mflux ;
            }
        }
      else
        {
          // boundary
          for (int f = 0; f < faces._CL.size(); f++)
            {
              int  const  cl   =   faces._CL[f];
              int  const  cr   =   faces._CR[f];

              double const
              mdot            =        ax[ f ] * 0.5 * (_xvel[cl] + _xvel[cr]) + ay[ f ] * 0.5 * (_yvel[cl] + _yvel[cr])  + az[ f ] * 0.5 * (_zvel[cl] + _zvel[cr]);

              if (mdot >= 0)
                {
                  _Ap[cl]          += mdot;
                }
              else
                {
                  _Ap[cl]          -= mdot;
                }

              double varf     =        ( mdot >= 0 ) ?  _alpha0[cl]  :  _alpha0[cr];

              _Src[cl]       -=        mdot * varf ;
            }
        }

    }

}




void
BaseSolver::
applyUrf(double urf)
{
  int ncells         =     _region._ncells;

  Matrix & matrix        ( _region. _matrix );

  double * mAp      =       matrix . getAii   ();
  double * mSrc     =       matrix . getSrc   ();

  for (int c = 0; c < ncells; c++)
    {
      mAp [ c ]     =      _Ap [c]/urf;
      mSrc[ c ]     =      _Src[c];
    }

}

void
BaseSolver::
acquireCorrection(double eurf)
{
  int ncells          =      _region._ncells;

  Matrix & matrix          ( _region. _matrix );

  double * alphaCorr  =       matrix . getPhi   ();

  for (int c = 0; c < ncells; c++)
    {
      double alp          =      _alpha0[c]  + eurf * alphaCorr[c];

      if ( alp < 0 ) alp  =       0;
      if ( alp > 1 ) alp  =       1;

      _alpha0[c]          =           alp;
      _alpha1[c]          =       1 - alp;
    }
}

