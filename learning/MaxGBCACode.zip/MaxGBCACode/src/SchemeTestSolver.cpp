#include "SchemeTestSolver.h"

SchemeTestSolver::
SchemeTestSolver()
: BaseSolver()
{
}

SchemeTestSolver::
~SchemeTestSolver()
{
}

void
SchemeTestSolver::
initialize(double u0, double v0)
{


  int nbcells  =  _region._ncellsBnd;


  _alphaInit.resize(  nbcells  );


  _alpha0.resize(  nbcells  );
  _alpha1.resize(  nbcells  );

  _alpha01.resize(  nbcells  );
  _alpha11.resize(  nbcells  );

  _alpha02.resize(  nbcells  );
  _alpha12.resize(  nbcells  );

  _xvel   .resize(  nbcells  );
  _yvel   .resize(  nbcells  );
  _zvel   .resize(  nbcells  );


  _dAlphadx0 .resize(  nbcells  );
  _dAlphady0 .resize(  nbcells  );
  _dAlphadz0 .resize(  nbcells  );

  _dAlphadx1 .resize(  nbcells  );
  _dAlphady1 .resize(  nbcells  );
  _dAlphadz1 .resize(  nbcells  );


  _alpha0Min .resize(  nbcells  );
  _alpha0Max .resize(  nbcells  );


  _Ap        .resize(  nbcells  );
  _Src       .resize(  nbcells  );


  for  (int c = 0; c < nbcells; c++ )
    {
      _alpha0[c]    =    0;
      _alpha1[c]    =    1 - _alpha0[c];

      if (  _region._yc[c] >=  _region._xc[c])
        {
          _alpha0[c]    =    1;
          _alpha1[c]    =    1 - _alpha0[c];
        }

      _alphaInit[c]   =  _alpha0[c];

      double vmag  =  std::sqrt( u0*u0 + v0*v0 );


      _xvel[c]   =  u0/vmag;
      _yvel[c]   =  v0/vmag;
      _zvel[c]   =  0;



    }

  // takes a single step of VOF solver
  memcpy(  _alpha01.data(), _alpha0.data(), sizeof(double) * _alpha0.size()  );
  memcpy(  _alpha11.data(), _alpha1.data(), sizeof(double) * _alpha1.size()  );

  memcpy(  _alpha02.data(), _alpha01.data(), sizeof(double) * _alpha0.size()  );
  memcpy(  _alpha12.data(), _alpha11.data(), sizeof(double) * _alpha1.size()  );


}

void
SchemeTestSolver::
applyBC()
{

  _isTransient  =  false;

  std::vector < CvFaces >  &  cvFaces  (  _region._cvFaces );

  for (int b = 1; b < cvFaces.size(); b++)
    {
      CvFaces  & faces( cvFaces[b] );

      std::vector < double > & ax (  faces._Ax );
      std::vector < double > & ay (  faces._Ay );
      std::vector < double > & az (  faces._Az );

      for (int f = 0; f < faces._CL.size(); f++)
        {
          int  const  cl    =    faces._CL[f];
          int  const  cr    =    faces._CR[f];

          double
          mdot            =        ax[ f ] * 0.5 * (_xvel[cl] + _xvel[cr]) + ay[ f ] * 0.5 * (_yvel[cl] + _yvel[cr])  + az[ f ] * 0.5 * (_zvel[cl] + _zvel[cr]);

          if ( mdot > 0 )
            {
              // outflow
              _alpha0[cr]   =  _alpha0[cl];
              _alpha1[cr]   =  _alpha1[cl];
            }

        }
    }


}
