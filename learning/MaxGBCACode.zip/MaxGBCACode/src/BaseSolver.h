

#ifndef SRC_BASESOLVER_H_
#define SRC_BASESOLVER_H_

#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <cmath>

#include "CvFaces.h"
#include "CvRegion.h"

#include "Settings.h"

#include <map>



class BaseSolver
{
public:
  BaseSolver();
  virtual ~BaseSolver();

  virtual   void     createRegion  ( double xmin, double xmax, double ymin, double ymax, int xdiv, int ydiv                      );
  virtual   void     setSettings   ( Settings  *  s ) {    _settings =  s;    }



  virtual   void     initialize    ( double u0, double v0) = 0;
  virtual   void     applyBC       () = 0;


  virtual   void     solve         ( double tmax, int innerItrs, double Courant);


  virtual   void     exportResults ( std::string baseN);
  virtual   double   adjustTimeStep( double _cmax, double _currDeltaT, double _delTMin, double _delTMax );

  virtual   void     timeStep      ( double time_, double dt, int innerItrs);


   // If the velocity changes every time-step then extend this function to adjust the velocity.
   //  Typically the velocity is function of time so it is passed here.
  virtual   void     preSolveUpdate( double time_ ,  double dt_ ) {}


  virtual   void     preprocessSubIteration ();
  virtual   void     postProcessSubIteration();

  virtual   void     calcMinMax( std::vector < double >  & alpha, std::vector < double >  & alphaMin, std::vector < double >  & alphaMax );

  virtual   void     gradient  ( std::vector < double >  & alpha, std::vector < double >  & alphadx, std::vector < double >  & alphady, std::vector < double >  & alphadz );

  virtual   void     unsteadyTerm(   );
  virtual   void     convectionTerm(double dt);

  virtual   int      getCurrentInnerIteration() { return _currentInnerIteration; }
  virtual   int      getSubTimeIterations       ()  { return _maxInnerIteration; }

  virtual   double   getCurrentDt0()  {  return _maindt0;  }
  virtual   double   getCurrentDt1()  {  return _maindt1;  }
  virtual   double   getCurrentDt2()  {  return _maindt2;  }

  virtual   void     applyUrf         ( double urf );
  virtual   void     acquireCorrection( double eurf );



protected:
  CvRegion                     _region;
  Settings  *                _settings;


  double                  _isTransient;
  double                          _urf;

  double                    _currTime0;
  double                  _currTimeNow;
  double                     _currTime;
  int            _currentTimeIteration;
  int           _currentInnerIteration;
  int               _maxInnerIteration;
  double                      _maindt0;
  double                      _maindt1;
  double                      _maindt2;


  std::vector < double >         _xvel;
  std::vector < double >         _yvel;
  std::vector < double >         _zvel;

  // vof markers
  std::vector < double >    _alphaInit;


  std::vector < double >       _alpha0;
  std::vector < double >       _alpha1;


  std::vector < double >    _alpha0Min;
  std::vector < double >    _alpha0Max;


  // at time level1
  std::vector < double >      _alpha01;
  std::vector < double >      _alpha11;

  std::vector < double >      _alpha02;
  std::vector < double >      _alpha12;



  // first vof marker
  std::vector < double >    _dAlphadx0;
  std::vector < double >    _dAlphady0;
  std::vector < double >    _dAlphadz0;

  // second vof marker
  std::vector < double >    _dAlphadx1;
  std::vector < double >    _dAlphady1;
  std::vector < double >    _dAlphadz1;

  std::vector < double >           _Ap;
  std::vector < double >          _Src;



};

#endif
