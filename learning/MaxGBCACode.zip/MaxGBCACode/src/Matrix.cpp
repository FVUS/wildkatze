#include "Matrix.h"

Matrix::
Matrix()
: _n(0)
, _nnz(0)
, _nmax(0)
, _Ai(0)
, _Aj(0)
, _index(0)
, _Ax   (0)
, _Aii  (0)
, _Src  (0)
, _Phi  (0)
{}

Matrix::
~Matrix()
{
  deleteAll    ();
}

void
Matrix::
init(int size)
{
  // first clean
  deleteAll();

  // now initialize
  _n      =     size;
  _Ai     =     new int [ _n + 2] ;

  std::memset (  _Ai, 0, sizeof(int)*(_n+2)  );
}

void
Matrix::
count(int cl)
{
  // this simply increases the count
  _Ai[cl+1]     +=     1;
}

void
Matrix::
finalizeCount()
{
  _nnz = 0;

  for (int i = 0; i < _n; i++)
    {
      _nnz += _Ai[i+1];
    }

  for (int i = 0; i < _n; i++)
    {
      _Ai[i+1] += _Ai[i] ;
    }

  _index    =    new int [ _n + 1] ;

  std::memcpy   (_index, _Ai, sizeof(int)*(_n+1) );


  delete   []    _Aj;

  _Aj      =     new int [ _nnz + 1];

  std::memset    (_Aj, 0, sizeof(int)*(_nnz+1) );

}

void
Matrix::
add(int cl, int cr)
{
  _Aj[ _index[cl] ]    =     cr;

  // increase
  _index[cl]          +=     1;

  if (cr > _nmax )
    {
      _nmax            =     cr;
    }

}

void
Matrix::
finalize()
{
  // we finalize and remove the repeated neighbors
  int *itemp;
  itemp = new int [ _nmax + 1] ;
  std::memset(itemp, 0, sizeof(int)*(_nmax+1) );

  int *tmpAi;
  tmpAi = new int [ _n + 1] ;
  tmpAi[0] = 0;


  int *tmpAj;
  tmpAj = new int [ _nnz + 2] ;


  int r = 0, rst = 0, rend = 0;
  int nnz = 0;
  int cr =0 ;

  for (int i = 0; i < _n; i++)
    {
      rst = _Ai[i];
      rend = _Ai[i + 1];

      for (r = rst; r < rend; r++)
        {
          cr = _Aj[r];
          if (itemp[cr] == 0)
            {
              itemp[cr] = 1;
              tmpAj[nnz] = cr;
              nnz++;
            }
        }

      tmpAi[i + 1] = nnz;

      // clean itemp
      for (r = rst; r < rend; r++)
        {
          itemp[_Aj[r]] = 0;
        }

    }


  delete [] _Aj;
  _Aj = new int [ nnz + 1];
  _nnz = nnz;


  delete [] _Ax;
  _Ax = new double [ nnz + 1];

  delete [] _Aii;
  delete [] _Src;
  delete [] _Phi;



  _Aii = new double [ _n + 1];
  _Src = new double [ _n + 1];
  _Phi = new double [ _n + 1];



  std::memcpy(_Ai, tmpAi, sizeof(int)*(_n + 1)) ;
  std::memcpy(_Aj, tmpAj, sizeof(int)*(_nnz + 1)) ;

  std::memset( _Ax,  0,  sizeof(double) * (nnz + 1) );

  std::memset( _Aii, 0,  sizeof(double) * (_n + 1) );
  std::memset( _Src, 0,  sizeof(double) * (_n + 1) );
  std::memset( _Phi, 0,  sizeof(double) * (_n + 1) );

  delete [] itemp;
  delete [] tmpAj;
  delete [] tmpAi;
}



int
Matrix::
getIndex(int  cl, int  cr)
{
  int  rst    =    _Ai[cl  ];
  int rend    =    _Ai[cl+1];

  for (int  r = rst; r < rend; r++)
    {
      if (cr == _Aj[r])
        return r;
    }

  return -1;
}


void
Matrix::
clearMatrix()
{

  memset(_Ax, 0, sizeof(double) * _nnz );
  memset(_Aii, 0, sizeof(double) * _n  );
  memset(_Src, 0, sizeof(double) * _n  );
  memset(_Phi, 0, sizeof(double) * _n  );
}



void
Matrix::
solve(int maxItr, double tol)
{
  memset(_Phi, 0, sizeof(double) * _n  );

  double res0  =  0;

  for (int c = 0; c < _n; c++)
    {
      res0   +=  std::fabs( _Src[c] );
    }

  if (res0 < 1.0E-18)
    {
      return;
    }

  double res1  =  res0;

  for (int itr = 0; itr < maxItr; itr++)
    {
      applyGS();

      res1  =  calcResidual();

      double ratio  =  res1 / res0;

      if (ratio < tol)
        return;

    }

}




double
Matrix::
calcResidual()
{
  double res  =  0;

  for (int c = 0; c < _n; c++)
    {
      int rst      =   _Ai[c];
      int rend     =   _Ai[c+1];

      double sum   =    0;

      for (int r = rst; r < rend; r++)
        {
          sum   +=    _Phi[ _Aj[r] ]  * _Ax[r];
        }

      res  +=  std::fabs( _Src[c] - sum  - _Phi[c] *  _Aii[c] );
    }

  return res;
}



void
Matrix::
applyGS()
{
  int  n1  =  _n - 1;

  for (int c = 0; c < _n; c++)
    {
      int rst      =   _Ai[c];
      int rend     =   _Ai[c+1];

      double sum   =    0;

      for (int r = rst; r < rend; r++)
        {
          sum   +=    _Phi[ _Aj[r] ]  * _Ax[r];
        }

      _Phi[c]    =   (_Src[c] - sum) / _Aii[c];
    }


  for (int c = n1; c >= 0; c--)
    {
      int rst      =   _Ai[c];
      int rend     =   _Ai[c+1];

      double sum   =    0;

      for (int r = rst; r < rend; r++)
        {
          sum   +=    _Phi[ _Aj[r] ]  * _Ax[r];
        }

      _Phi[c]    =   (_Src[c] - sum) / _Aii[c];
    }

}
