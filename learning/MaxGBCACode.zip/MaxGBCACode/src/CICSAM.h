
#ifndef SRC_CICSAM_H_
#define SRC_CICSAM_H_


#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <cmath>



double
weightCICSAM_M
(
    const double cdWeight,
    const double faceFlux,
    const double& phiP,
    const double& phiN,
    const double& gradcP_x, const double & gradcP_y,  const double & gradcP_z,
    const double& gradcN_x, const double & gradcN_y,  const double & gradcN_z,
    const double& phiMin,
    const double& phiMax,
    const double Cof,
    const double d_x, const double d_y, const double d_z
)
{
  double SMALL = 1.0E-20;

  if ((faceFlux > 0 && (phiP < 0.0 || phiN > 1.0)))
    {
      return 1;
    }
  else if ((faceFlux < 0 && (phiN < 0.0 || phiP > 1.0)))
    {
      return 0;
    }

  // Calculate upwind value, faceFlux C tilde and do a stabilisation
  double phict    = 0;
  double phiupw   = 0;
  double costheta = 0;

  if (faceFlux > 0)
    {
      double gradDotD = gradcP_x * d_x + gradcP_y * d_y + gradcP_z * d_z;

      costheta = std::fabs( gradDotD/
                            (
                                std::sqrt( gradcP_x * gradcP_x + gradcP_y * gradcP_y + gradcP_z * gradcP_y ) *
                                std::sqrt( d_x      * d_x      + d_y      * d_y      + d_z * d_z ) + SMALL));

      phiupw  =  phiN - 2.0*gradDotD;

      phiupw = std::max(  std::min(phiupw, 1.0), 0.0);

      if ((phiN - phiupw) > 0)
        {
          phict = (phiP - phiupw) / (phiN - phiupw + SMALL);
        }
      else
        {
          phict = (phiP - phiupw) / (phiN - phiupw - SMALL);
        }
    }
  else
    {
      double gradDotD = gradcN_x * d_x + gradcN_y * d_y + gradcN_z * d_z;

      costheta = std::fabs( gradDotD/
                            (
                                std::sqrt( gradcN_x * gradcN_x + gradcN_y * gradcN_y + gradcN_z * gradcN_y ) *
                                std::sqrt( d_x      * d_x      + d_y      * d_y      + d_z * d_z ) + SMALL));

      phiupw = phiP + 2 * gradDotD;

      phiupw = std::max(  std::min(phiupw, 1.0), 0.0);

      if ((phiP - phiupw) > 0)
        {
          phict = (phiN - phiupw) / (phiP - phiupw + SMALL);
        }
      else
        {
          phict = (phiN - phiupw) / (phiP - phiupw - SMALL);
        }
    }

  // Calculate the weighting factors for CICSAM
  double   k_      = 0.55 ;

  double
  cicsamFactor  =    (k_ + SMALL) / (1 - k_ + SMALL);

  costheta      =     std::min(1.0, cicsamFactor * (costheta));
  costheta      =    (std::cos(2 * ( std::acos(costheta))) + 1) / 2.0;

  double Ck     =    (Cof < 0.3) ? 0.3 : Cof;

  double k1     =    (3 * Ck * Ck - 3 * Ck) / (2 * Ck * Ck + 6 * Ck - 8.0);
  double k2     =     Ck;
  double k3     =    (3 * Ck + 5) / (2 * Ck + 6.0);

  double weight;

  if (phict > 0 && phict <= k1) // use blended scheme 1
    {
      double
      phifCM    =     std::min(phict / (Cof + SMALL), 1.0);
      weight    =    (phifCM - phict) / (1 - phict);
    }
  else if (phict > k1 && phict <= k2) // use blended scheme 2
    {
      double
      phifHC    =     std::min(phict / (Cof + SMALL), 1.0);
      double
      phifUQ    =     std::min((8 * Cof * phict + (1 - Cof) * (6 * phict + 3)) / 8.0, 1.0);
      double
      phifCM    =     costheta * phifHC + (1 - costheta) * phifUQ;
      weight    =     (phifCM - phict) / (1 - phict);
    }
  else if (phict > k2 && phict < k3) // use blended scheme 3
    {
      double
      phifHC    =     std::min(phict / (k2 + SMALL), 1.0);

      double
      //phifUQ    =     (8 * Cof * phict + (1 - Cof) * (6 * phict + 3)) / 8.0;
      phifUQ    =     std::max((8 * Cof * phict + (1 - Cof) * (6 * phict + 3)) / 8.0, phifHC);

      double
      phifCM    =     costheta + (1 - costheta) * phifUQ;
      weight    =     (phifCM - phict) / (1 - phict);
    }
  else if (phict >= k3 && phict <= 1) // use downwind
    {
      weight    =     1;
    }
  else // use upwind
    {
      weight    =     0;
    }


  if (faceFlux > 0)
    {
      return 1 - weight;
    }
  else
    {
      return weight;
    }
}




double CICSAM(  double  dt, double  vol0, double  vol1
             ,  double  xf,  double  yf,  double  zf
             ,  double  ax,  double  ay,  double  az


             ,  double t_xc, double t_yc, double t_zc
             ,  double h_xc, double h_yc, double h_zc

             ,  double  Y0, double  Y1
             ,  double dYdx0 , double dYdy0 , double dYdz0
             ,  double dYdx1 , double dYdy1 , double dYdz1
             ,  double mdot
             ,  double xVel0 , double  yVel0, double zVel0
             ,  double xVel1 , double  yVel1, double zVel1

)
{

      double flagUpwind;

      double Yu   =     Y0;
      double Yd   =     Y1;

      double dYdxu ,  dYdyu ,  dYdzu;
      double dYdxd ,  dYdyd ,  dYdzd;
      double xVelu ,   yVelu,  zVelu;

      double xcu, ycu, zcu;

      double  volu;

      if (mdot > 0)
        {
          flagUpwind    =     1;

          dYdxu         =      dYdx0;
          dYdyu         =      dYdy0;
          dYdzu         =      dYdz0;

          dYdxd         =      dYdx1;
          dYdyd         =      dYdy1;
          dYdzd         =      dYdz1;

          xVelu         =      xVel0;
          yVelu         =      yVel0;
          zVelu         =      zVel0;

          xcu           =      t_xc;
          ycu           =      t_yc;
          zcu           =      t_zc;

          volu          =      vol0;

        }
      else
        {
          flagUpwind    =     -1;
          Yu   =     Y1;
          Yd   =     Y0;


          dYdxu         =      dYdx1;
          dYdyu         =      dYdy1;
          dYdzu         =      dYdz1;

          dYdxd         =      dYdx0;
          dYdyd         =      dYdy0;
          dYdzd         =      dYdz0;


          xVelu         =      xVel1;
          yVelu         =      yVel1;
          zVelu         =      zVel1;


          xcu           =      h_xc;
          ycu           =      h_yc;
          zcu           =      h_zc;

          volu          =      vol1;


        }

      double Ymin =     (Yu < Yd) ? Yu : Yd;
      double Ymax =     (Yu > Yd) ? Yu : Yd;

      double       vdotAf  =    xVelu * ax + yVelu*ay + zVelu*az;

      double const Cof     =  std::fabs(  vdotAf*flagUpwind*dt/volu );  // same as CFL in HRIC

      double const cdWeight = 0.5;

      // lets call weight CICSAM
      double wtCicsam =     weightCICSAM_M
                                        (
                                            cdWeight, // should change to appropiate wt dist1/(dist0 + dist1)
                                            mdot,
                                            Y0,
                                            Y1,
                                            dYdx0, dYdy0, dYdz0,
                                            dYdx1, dYdy1, dYdz1,
                                            0, 1,
                                            Cof,
                                            h_xc-t_xc, h_yc-t_yc, h_zc-t_zc
                                        );

      // Calculate CICSAM face value
      double phif = wtCicsam*Y0 + (1 - wtCicsam)*Y1;

      // Calculate UD and CD face value
      double phiU  =  Yu;
      double phiCD =  cdWeight*Y0 + (1 - cdWeight)*Y1;

      // Calculate the effective limiter for the CICSAM interpolation
      double CLimiter =  ( std::fabs(phiCD - phiU) > 1.0E-18  ) ?
                             (phif - phiU)  /  (phiCD - phiU + 1.0E-18)
                             : 1;

      if ( CLimiter > 2.0 ) CLimiter = 2.0;
      if ( CLimiter < 0.0 ) CLimiter = 0.0;

      double Yf =  Yu + CLimiter *  (
                                      dYdxu *  (xf-xcu) +
                                      dYdyu *  (yf-ycu) +
                                      dYdzu *  (zf-zcu)
                                    );

      if (Yf < 0) Yf = 0;
      if (Yf > 1) Yf = 1;

      return Yf;

}



#endif
