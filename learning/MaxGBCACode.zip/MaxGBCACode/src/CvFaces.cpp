
#include "CvFaces.h"

CvFaces::
CvFaces()
: _FaceType(0)  // type 0 is boundary by default
{
}

CvFaces::
~CvFaces()
{
}

