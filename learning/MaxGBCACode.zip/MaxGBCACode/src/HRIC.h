

#ifndef SRC_HRIC_H_
#define SRC_HRIC_H_


#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <cmath>

  double
  HRIC(
                bool & transient, double & dt, double & volu
             ,  double & CflLower, double & CflUpper, double & a1, double & a2
             ,  double & xf,  double & yf,  double & zf
             ,  double & ax,  double & ay,  double & az
             ,  double & xcu, double & ycu, double & zcu
             ,  double & xcd, double & ycd, double & zcd
             ,  double &mdot, double & YuSide, double & YdSide
             ,  double &dYdxu , double &dYdyu , double &dYdzu
             ,  double &dYdxd , double &dYdyd , double &dYdzd
             ,  double & xVelu , double & yVelu, double & zVelu
             ,  double & _downwindSharpening, double & _downwindSharpening0
             ,  double & YminGlob, double & YmaxGlob, double &    _angleFac
            )
  {


    double const CFL_dif = CflUpper - CflLower;

    // Concentration Yu upstream from face f
    double const Yu = YuSide;
      // Concentration Yd downstream from face f
    double Yd = YdSide;

    if (  std::fabs( Yd - Yu ) < 1.0E-8 )
      {
        return Yu;
      }


    double Ymin =     (Yu < Yd) ? Yu : Yd;
    double Ymax =     (Yu > Yd) ? Yu : Yd;

    double Yuu  =   Yd
                   -2 *
                         (
                             dYdxu *  (xcd-xcu) +
                             dYdyu *  (ycd-ycu) +
                             dYdzu *  (zcd-zcu)
                         );

    if (Yuu > 1.0)    {  Yuu = 1.0;    }    else if (Yuu < 0  )     {      Yuu = 0;      }
    if (Yuu < YminGlob ) Yuu =     YminGlob;
    if (Yuu > YmaxGlob ) Yuu =     YmaxGlob;


    // Construct face normalized variable alfa_f and upstream cell normalized variable alfa_u
    double alfa_f, alfa_u;
    double const Yd_Yuu = Yd - Yuu;
    bool useUpwind = false;

    if (std::fabs(Yd_Yuu) <  1.0e-20 )
      {
        useUpwind = true;
      }
    else
      {
        // Construct
        alfa_u = (Yu - Yuu)/Yd_Yuu;
        if      (alfa_u < 0.0 )
          {
            useUpwind = true;
          }
        else if (alfa_u <  0.3 )
          {
            alfa_f = (a1 + a2*alfa_u)*alfa_u;
          }
        else if (alfa_u < 1)
          {
            alfa_f = 1;
          }
        else
          {
            useUpwind = true;
          }
      }

    if (!useUpwind)
      {
        // Correct alfa_f to satisfy local currant number criterion
        if (transient)
          {
            double       vdotA   =    xVelu * ax + yVelu*ay + zVelu*az ;

            double const CFL     =   std::fabs(    vdotA*dt/volu  );

            if (CFL < CflLower)
              {
                // Do not modify alfa_f
                ;
              }
            else if (CFL < CflUpper)
              {
                // Interpolate between alfa_f and alfa_u
                alfa_f = alfa_u + (alfa_f - alfa_u)*(CflUpper - CFL)/CFL_dif;
              }
            else
              {
                useUpwind = true;
              }
          }
      }

    // Calculate face value
    if (useUpwind)
      {
        // Upwind face value
        return Yu;
      }
    else
      {
        // Correct alfa_f according to the shape of the interface
        // we try to find a weighted gradient to find the angle
        double gwt =  std::max( YuSide / (YuSide + YdSide + 1.0E-10 ), 0.4 );
        double gdYdx = gwt*dYdxu + (1-gwt)*dYdxd;
        double gdYdy = gwt*dYdyu + (1-gwt)*dYdyd;
        double gdYdz = gwt*dYdzu + (1-gwt)*dYdzd;

        /// old code
        double aFac  = std::sqrt
                            (
                                (ax*ax + ay*ay + az*az) *
                                (gdYdx*gdYdx + gdYdy*gdYdy + gdYdz*gdYdz )
                             );

        {
          if (aFac > 1.0e-20)
            {
              aFac = std::pow(  std::fabs( gdYdx*ax + gdYdy*ay + gdYdz*az )/ (aFac + 1.0E-20), _angleFac);
              alfa_f = alfa_f*aFac + alfa_u*(1.-aFac);
            }
          else
            {
              alfa_f = alfa_u;
            }
        }

        // Blended face value
        return (alfa_f*(Yd - Yuu) + Yuu);
      }

    return Yu;
  }




#endif
