
#ifndef SRC_MATRIX_H_
#define SRC_MATRIX_H_


#include <iostream>
#include <string>
#include <cstring>
#include <string.h>
#include <vector>
#include <cmath>

class Matrix
{
public:
  Matrix();
  virtual ~Matrix();

  virtual  void init         (int size);
  virtual  void count        (int cl);

  // we allocate the nnz and Aj index according.
  virtual  void finalizeCount();
  virtual  void add          (int cl, int cr);
  virtual  void finalize     ();

  int  getIndex(int  cl, int  cr);

  int *getAi   () const  {    return _Ai;    }
  int *getAj   () const  {    return _Aj;    }
  int  getN    () const  {    return _n;     }
  int  getNNZ  () const  {    return _nnz;   }

  double *getAx    ()    {    return _Ax;    }
  double *getAii   ()    {    return _Aii;    }
  double *getSrc   ()    {    return _Src;    }
  double *getPhi   ()    {    return _Phi;    }


  void    solve( int maxItr , double tol );
  void    applyGS();

  double  calcResidual();


  void clearMatrix ();

  virtual
  void deleteAll    ()
  {
    delete [] _Ai;
    delete [] _Aj;
    delete [] _index;
    delete [] _Ax;

    delete [] _Aii;
    delete [] _Src;
    delete [] _Phi;

    _n     = 0;
    _nnz   = 0;
    _nmax  = 0;
    _Ai    = 0;
    _Aj    = 0;
    _index = 0;
    _Ax    = 0;

    _Aii   = 0;
    _Src   = 0;

    _Phi   =  0;
  }


private:
  int          _n;
  int          _nnz;
  int          _nmax;
  int       *  _Ai;
  int       *  _Aj;
  int       *  _index;

  double    *  _Ax;
  double    *  _Aii;  // diagonal
  double    *  _Src;
  double    *  _Phi;

};

#endif
