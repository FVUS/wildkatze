

#include "CvRegion.h"

CvRegion::CvRegion()
{

}

CvRegion::~CvRegion()
{

}


void
CvRegion::
createRegion(double xmin, double xmax, double ymin, double ymax, int xdiv,  int ydiv)
{

  _xdiv  =  xdiv;
  _ydiv  =  ydiv;

  std::vector < double >        tmpxc;
  std::vector < double >        tmpyc;
  std::vector < double >        tmpzc;  // going to be 0 here

  tmpxc.resize(  (xdiv+2)* (ydiv+2) );
  tmpyc.resize(  (xdiv+2)* (ydiv+2) );
  tmpzc.resize(  (xdiv+2)* (ydiv+2) );

  cellType.resize(  (xdiv+2)* (ydiv+2) );
  cellIds.resize(  (xdiv+2)* (ydiv+2) );

  int const  Nj   =  ydiv+2;

  // pre allocating them because we know the size
  _volume.resize( xdiv*ydiv + 2*(xdiv + ydiv)  );
  _xc    .resize( xdiv*ydiv + 2*(xdiv + ydiv)  );
  _yc    .resize( xdiv*ydiv + 2*(xdiv + ydiv)  );
  _zc    .resize( xdiv*ydiv + 2*(xdiv + ydiv)  );



  double const  dx  =  (xmax-xmin)/xdiv;
  double const  dy  =  (ymax-ymin)/ydiv;


  // the temperary cell centers
  for (int i = 0; i <= (xdiv+1); i++)
    {
      for (int j = 0; j <= (ydiv+1); j++)
        {
          tmpxc   [i*Nj + j]    =     xmin + 0.5*dx + (i-1)*dx;
          tmpyc   [i*Nj + j]    =     ymin + 0.5*dy + (j-1)*dy;
          tmpzc   [i*Nj + j]    =     0;
        }
    }


  for (int i = 0; i <= (xdiv+1); i++)
    {
      for (int j = 0; j <= (ydiv+1); j++)
        {
          cellType[i*Nj + j]    =     0;
          cellIds [i*Nj + j]    =     0;
        }
    }


  int cIds        =  0;

  // marking the live cells
  for (int i = 1; i <=  xdiv ; i++)
    {
      for (int j = 1; j <=  ydiv ; j++)
        {
          cIds++;
          cellType[i*Nj + j]    =     1;
          cellIds [i*Nj + j]    =     cIds;

          int c  =  cellIds [i*Nj + j]  - 1;  // 0 based index
          _xc    [c]   =  tmpxc   [i*Nj + j];
          _yc    [c]   =  tmpyc   [i*Nj + j];
          _zc    [c]   =  tmpzc   [i*Nj + j];
          _volume[c]   =  dx*dy;

        }
    }

  int const ncells  =  cIds;

  // the boundary cells
  for (int i = 1; i <=  xdiv ; i++)
    {
      for (int j = 1; j <=  ydiv ; j++)
        {
          // boundary cells
          {
            int ib  =  i-1;
            int jb  =  j;

            if (cellIds [ib*Nj + jb] == 0)
              {
                cIds++;
                cellType[ib*Nj + jb]    =     0;
                cellIds [ib*Nj + jb]    =     cIds;

                int c  =  cellIds [ib*Nj + jb]  - 1;  // 0 based index
                _xc    [c]   =  0.5*(tmpxc   [i*Nj + j] + tmpxc   [ib*Nj + jb] );
                _yc    [c]   =  0.5*(tmpyc   [i*Nj + j] + tmpyc   [ib*Nj + jb] );
                _zc    [c]   =  0.5*(tmpzc   [i*Nj + j] + tmpzc   [ib*Nj + jb] );
                _volume[c]   =  0;

              }
          }

          {
            int ib  =  i+1;
            int jb  =  j;

            if (cellIds [ib*Nj + jb] == 0)
              {
                cIds++;
                cellType[ib*Nj + jb]    =     0;
                cellIds [ib*Nj + jb]    =     cIds;

                int c  =  cellIds [ib*Nj + jb]  - 1;  // 0 based index
                _xc    [c]   =  0.5*(tmpxc   [i*Nj + j] + tmpxc   [ib*Nj + jb] );
                _yc    [c]   =  0.5*(tmpyc   [i*Nj + j] + tmpyc   [ib*Nj + jb] );
                _zc    [c]   =  0.5*(tmpzc   [i*Nj + j] + tmpzc   [ib*Nj + jb] );
                _volume[c]   =  0;

              }
          }

          {
            int ib  =  i;
            int jb  =  j-1;

            if (cellIds [ib*Nj + jb] == 0)
              {
                cIds++;
                cellType[ib*Nj + jb]    =     0;
                cellIds [ib*Nj + jb]    =     cIds;

                int c  =  cellIds [ib*Nj + jb]  - 1;  // 0 based index
                _xc    [c]   =  0.5*(tmpxc   [i*Nj + j] + tmpxc   [ib*Nj + jb] );
                _yc    [c]   =  0.5*(tmpyc   [i*Nj + j] + tmpyc   [ib*Nj + jb] );
                _zc    [c]   =  0.5*(tmpzc   [i*Nj + j] + tmpzc   [ib*Nj + jb] );
                _volume[c]   =  0;

              }
          }

          {
            int ib  =  i;
            int jb  =  j+1;

            if (cellIds [ib*Nj + jb] == 0)
              {
                cIds++;
                cellType[ib*Nj + jb]    =     0;
                cellIds [ib*Nj + jb]    =     cIds;

                int c  =  cellIds [ib*Nj + jb]  - 1;  // 0 based index
                _xc    [c]   =  0.5*(tmpxc   [i*Nj + j] + tmpxc   [ib*Nj + jb] );
                _yc    [c]   =  0.5*(tmpyc   [i*Nj + j] + tmpyc   [ib*Nj + jb] );
                _zc    [c]   =  0.5*(tmpzc   [i*Nj + j] + tmpzc   [ib*Nj + jb] );
                _volume[c]   =  0;

              }
          }

        }
    }


  int const ncellsWithBnds  =  cIds;

  _ncells           =   ncells;
  _ncellsBnd        =   ncellsWithBnds;


  std::cout << " Cells created =  " << ncells << ", with boundaries = " <<  ncellsWithBnds << std::endl;

  // finally we create a finite volume region faces

  _cvFaces.resize(2);

  for (int i = 1; i <=  xdiv ; i++)
    {
      for (int j = 1; j <=  ydiv ; j++)
        {
          int const ctype  =  cellType[i*Nj + j] ;
          int const cid = cellIds [i*Nj + j]   - 1;

          // cv faces cells
          {
            int ib  =  i-1;
            int jb  =  j;
            int btype  =  cellType[ib*Nj + jb] ;
            int const bid = cellIds [ib*Nj + jb]   - 1;

            double Ar  =  dy;


            if ( ctype > 0 && btype > 0 )
              {
                // internal face , only half of them are added
                if ( bid > cid )
                  {
                    // zero based indexing
                    _cvFaces[0]._CL.push_back( cid );
                    _cvFaces[0]._CR.push_back( bid );

                    _cvFaces[0]._Amag.push_back( Ar );

                    _cvFaces[0]._Ax  .push_back( -Ar );
                    _cvFaces[0]._Ay  .push_back( 0 );
                    _cvFaces[0]._Az  .push_back( 0 );

                    _cvFaces[0]._fx  .push_back( 0.5*( _xc    [bid] + _xc    [cid]) );
                    _cvFaces[0]._fy  .push_back( 0.5*( _yc    [bid] + _yc    [cid]) );
                    _cvFaces[0]._fz  .push_back( 0.5*( _zc    [bid] + _zc    [cid]) );

                  }
              }
            else
              {
                // boundary face

                _cvFaces[1]._CL.push_back( cid );
                _cvFaces[1]._CR.push_back( bid );

                _cvFaces[1]._Amag.push_back( Ar );
                _cvFaces[1]._Ax  .push_back( _xc    [bid] - _xc    [cid] );
                _cvFaces[1]._Ay  .push_back( _yc    [bid] - _yc    [cid] );
                _cvFaces[1]._Az  .push_back( _zc    [bid] - _zc    [cid] );

                _cvFaces[1]._fx  .push_back(  _xc    [bid] );
                _cvFaces[1]._fy  .push_back(  _yc    [bid] );
                _cvFaces[1]._fz  .push_back(  _zc    [bid] );
              }
          }

          //i + 1
          {
            int ib  =  i+1;
            int jb  =  j;
            int btype     =  cellType[ib*Nj + jb] ;
            int const bid = cellIds [ib*Nj + jb]   - 1;

            double Ar  =  dy;


            if ( ctype > 0 && btype > 0 )
              {
                // internal face , only half of them are added
                if ( bid > cid )
                  {
                    // zero based indexing
                    _cvFaces[0]._CL.push_back( cid );
                    _cvFaces[0]._CR.push_back( bid );

                    _cvFaces[0]._Amag.push_back( Ar );

                    _cvFaces[0]._Ax  .push_back( Ar );
                    _cvFaces[0]._Ay  .push_back( 0 );
                    _cvFaces[0]._Az  .push_back( 0 );

                    _cvFaces[0]._fx  .push_back( 0.5*( _xc    [bid] + _xc    [cid]) );
                    _cvFaces[0]._fy  .push_back( 0.5*( _yc    [bid] + _yc    [cid]) );
                    _cvFaces[0]._fz  .push_back( 0.5*( _zc    [bid] + _zc    [cid]) );

                  }
              }
            else
              {
                // boundary face

                _cvFaces[1]._CL.push_back( cid );
                _cvFaces[1]._CR.push_back( bid );

                _cvFaces[1]._Amag.push_back( Ar );
                _cvFaces[1]._Ax  .push_back( _xc    [bid] - _xc    [cid] );
                _cvFaces[1]._Ay  .push_back( _yc    [bid] - _yc    [cid] );
                _cvFaces[1]._Az  .push_back( _zc    [bid] - _zc    [cid] );

                _cvFaces[1]._fx  .push_back(  _xc    [bid] );
                _cvFaces[1]._fy  .push_back(  _yc    [bid] );
                _cvFaces[1]._fz  .push_back(  _zc    [bid] );
              }
          }

          // j - 1
          {
            int ib  =  i;
            int jb  =  j-1;
            int btype  =  cellType[ib*Nj + jb] ;
            int const bid = cellIds [ib*Nj + jb]   - 1;

            double Ar  =  dx;


            if ( ctype > 0 && btype > 0 )
              {
                // internal face , only half of them are added
                if ( bid > cid )
                  {
                    // zero based indexing
                    _cvFaces[0]._CL.push_back( cid );
                    _cvFaces[0]._CR.push_back( bid );

                    _cvFaces[0]._Amag.push_back( Ar );

                    _cvFaces[0]._Ax  .push_back( 0 );
                    _cvFaces[0]._Ay  .push_back( -Ar );
                    _cvFaces[0]._Az  .push_back( 0 );

                    _cvFaces[0]._fx  .push_back( 0.5*( _xc    [bid] + _xc    [cid]) );
                    _cvFaces[0]._fy  .push_back( 0.5*( _yc    [bid] + _yc    [cid]) );
                    _cvFaces[0]._fz  .push_back( 0.5*( _zc    [bid] + _zc    [cid]) );

                  }
              }
            else
              {
                // boundary face

                _cvFaces[1]._CL.push_back( cid );
                _cvFaces[1]._CR.push_back( bid );

                _cvFaces[1]._Amag.push_back( Ar );
                _cvFaces[1]._Ax  .push_back( _xc    [bid] - _xc    [cid] );
                _cvFaces[1]._Ay  .push_back( _yc    [bid] - _yc    [cid] );
                _cvFaces[1]._Az  .push_back( _zc    [bid] - _zc    [cid] );

                _cvFaces[1]._fx  .push_back(  _xc    [bid] );
                _cvFaces[1]._fy  .push_back(  _yc    [bid] );
                _cvFaces[1]._fz  .push_back(  _zc    [bid] );
              }
          }

          // j + 1
          {
            int ib  =  i;
            int jb  =  j+1;
            int btype  =  cellType[ib*Nj + jb] ;
            int const bid = cellIds [ib*Nj + jb]   - 1;

            double Ar  =  dx;


            if ( ctype > 0 && btype > 0 )
              {
                // internal face , only half of them are added
                if ( bid > cid )
                  {
                    // zero based indexing
                    _cvFaces[0]._CL.push_back( cid );
                    _cvFaces[0]._CR.push_back( bid );

                    _cvFaces[0]._Amag.push_back( Ar );

                    _cvFaces[0]._Ax  .push_back( 0 );
                    _cvFaces[0]._Ay  .push_back( Ar );
                    _cvFaces[0]._Az  .push_back( 0 );

                    _cvFaces[0]._fx  .push_back( 0.5*( _xc    [bid] + _xc    [cid]) );
                    _cvFaces[0]._fy  .push_back( 0.5*( _yc    [bid] + _yc    [cid]) );
                    _cvFaces[0]._fz  .push_back( 0.5*( _zc    [bid] + _zc    [cid]) );

                  }
              }
            else
              {
                // boundary face

                _cvFaces[1]._CL.push_back( cid );
                _cvFaces[1]._CR.push_back( bid );

                _cvFaces[1]._Amag.push_back( Ar );
                _cvFaces[1]._Ax  .push_back( _xc    [bid] - _xc    [cid] );
                _cvFaces[1]._Ay  .push_back( _yc    [bid] - _yc    [cid] );
                _cvFaces[1]._Az  .push_back( _zc    [bid] - _zc    [cid] );

                _cvFaces[1]._fx  .push_back(  _xc    [bid] );
                _cvFaces[1]._fy  .push_back(  _yc    [bid] );
                _cvFaces[1]._fz  .push_back(  _zc    [bid] );
              }
          }

        }
    }

  // we fix the area vectors
  for (int b = 0; b < _cvFaces.size(); b++)
    {
      CvFaces  & faces( _cvFaces[b] );

      for (int f = 0; f < faces._CL.size(); f++)
        {
          double  aamag  =  std::sqrt( faces._Ax[f] * faces._Ax[f]  +  faces._Ay[f] * faces._Ay[f] + faces._Az[f] * faces._Az[f] );
          faces._Ax[f]   =    ( faces._Ax[f] * faces._Amag[f])/aamag;
          faces._Ay[f]   =    ( faces._Ay[f] * faces._Amag[f])/aamag;
          faces._Az[f]   =    ( faces._Az[f] * faces._Amag[f])/aamag;
        }
    }


  // the nodes finally
  _nodeIds.resize( (xdiv+1)*(ydiv+1) );
  _xn     .resize( (xdiv+1)*(ydiv+1) );
  _yn     .resize( (xdiv+1)*(ydiv+1) );
  _zn     .resize( (xdiv+1)*(ydiv+1) );

  int nnodes  =  0;

  for (int i = 0; i <=  xdiv ; i++)
    {
      for (int j = 0; j <=  ydiv ; j++)
        {
          _nodeIds[ i * (ydiv+1) + j]   =   nnodes;

          _xn [ nnodes ]   =  xmin + i * dx;
          _yn [ nnodes ]   =  ymin + j * dy;
          _zn [ nnodes ]   =  0;

          nnodes++;
        }
    }


  // used for cell to nodes interpolation
  _cellsForNode.init( nnodes );

  for (int i = 1; i <=  xdiv ; i++)
    {
      for (int j = 1; j <=  ydiv ; j++)
        {
          // each cell has four nodes
          int const cid   =   cellIds [i*Nj + j]   - 1;

          // cv faces cells
          {
            int ib  =  i-1;
            int jb  =  j-1;

            int nid  =  _nodeIds[ ib * (ydiv+1) + jb];

            _cellsForNode.count(nid);
          }

          {
            int ib  =  i;
            int jb  =  j-1;

            int nid  =  _nodeIds[ ib * (ydiv+1) + jb];

            _cellsForNode.count(nid);
          }

          {
            int ib  =  i;
            int jb  =  j;

            int nid  =  _nodeIds[ ib * (ydiv+1) + jb];

            _cellsForNode.count(nid);
          }

          {
            int ib  =  i-1;
            int jb  =  j;

            int nid  =  _nodeIds[ ib * (ydiv+1) + jb];

            _cellsForNode.count(nid);
          }

        }
    }

  _cellsForNode.finalizeCount();


  for (int i = 1; i <=  xdiv ; i++)
    {
      for (int j = 1; j <=  ydiv ; j++)
        {
          // each cell has four nodes
          int const cid   =   cellIds [i*Nj + j]   - 1;

          // cv faces cells
          {
            int ib  =  i-1;
            int jb  =  j-1;

            int nid  =  _nodeIds[ ib * (ydiv+1) + jb];

            _cellsForNode.add(nid, cid);
          }

          {
            int ib  =  i;
            int jb  =  j-1;

            int nid  =  _nodeIds[ ib * (ydiv+1) + jb];

            _cellsForNode.add(nid, cid);
          }

          {
            int ib  =  i;
            int jb  =  j;

            int nid  =  _nodeIds[ ib * (ydiv+1) + jb];

            _cellsForNode.add(nid, cid);
          }

          {
            int ib  =  i-1;
            int jb  =  j;

            int nid  =  _nodeIds[ ib * (ydiv+1) + jb];

            _cellsForNode.add(nid, cid);
          }

        }
    }


  _cellsForNode.finalize ();


  createRegionMatrix();
}

void
CvRegion::
interpolateToNodes(std::vector<double>& cellD, std::vector<double>& nodeD)
{

  int  * Ai  = _cellsForNode.getAi();
  int  * Aj  = _cellsForNode.getAj();

  for (int n = 0; n < _xn.size(); n++)
    {
      int const rst   =  Ai[n];
      int const rend  =  Ai[n+1];

      double sum  =  0;

      for (int r = rst; r < rend; r++)
        {
          sum   +=   cellD[ Aj[r] ];
        }


      nodeD[n]    =   sum /( rend - rst );
    }

}

void
CvRegion::
createRegionMatrix()
{
  // only interior face is used
  CvFaces  & faces( _cvFaces[0] );

  _matrix.init( _ncells );

  for (int f = 0; f < faces._CL.size(); f++)
    {
      int const cl   =   faces._CL[f];
      int const cr   =   faces._CR[f];

      _matrix.count(cl);
      _matrix.count(cr);
    }

  _matrix.finalizeCount();

  for (int f = 0; f < faces._CL.size(); f++)
    {
      int const cl   =   faces._CL[f];
      int const cr   =   faces._CR[f];

      _matrix.add(cl, cr);
      _matrix.add(cr, cl);
    }

  _matrix.finalize();


  faces._indexLeft  .resize( faces._CL.size() );
  faces._indexRight .resize( faces._CL.size() );

  for (int f = 0; f < faces._CL.size(); f++)
    {
      int const cl   =   faces._CL[f];
      int const cr   =   faces._CR[f];

      faces._indexLeft   [f]    =   _matrix.getIndex(cl, cr);
      faces._indexRight  [f]    =   _matrix.getIndex(cr, cl);
    }

}


