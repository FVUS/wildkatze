
#ifndef SRC_DISCSOLVER_H_
#define SRC_DISCSOLVER_H_

#include "BaseSolver.h"


class DiscSolver  :   public BaseSolver
{
public:
  DiscSolver();
  virtual ~DiscSolver();

  void     initialize    (double u0, double v0);

  void     applyBC       (   ){}

};

#endif
