#ifndef _MaxGBCA_h_
#define _MaxGBCA_h_

#include <cmath>
#include <cstdlib>
#include <iostream>


class MaxGBCA
{

  double          _AdotDY;
  double    _angleWtFactor;
  double           _AFact;

  double        _angleFac;
  double       _sharpness;


public:
             MaxGBCA();
  virtual   ~MaxGBCA();



  double
  faceFractionS(
      std::string schemeOp
             ,  double  xf,  double  yf,  double  zf
             ,  double  ax,  double  ay,  double  az
             ,  double  xcu, double  ycu, double  zcu
             ,  double  xcd, double  ycd, double  zcd
             ,  double mdot, double  YuSide, double  YdSide
             ,  double dYdxu , double dYdyu , double dYdzu
             ,  double dYdxd , double dYdyd , double dYdzd
             ,  double xVelu , double  yVelu, double zVelu
            )
  {

    // if we need the scheme or not
    if (  std::fabs( YdSide - YuSide ) < 1.0E-8 )
      {
        return YuSide;
      }

    _AdotDY        =   1.0;
    _angleWtFactor =   0.0;



    // we compute the angle of the surface
    {
      // we try to find a weighted gradient to find the angle
      double gwt   =  std::min( 0.9,  std::max( YuSide / (YuSide + YdSide + 1.0E-10 ), 0.1 ));

      double gdYdx =  gwt*dYdxu + (1-gwt)*dYdxd;
      double gdYdy =  gwt*dYdyu + (1-gwt)*dYdyd;
      double gdYdz =  gwt*dYdzu + (1-gwt)*dYdzd;


      _AFact       = std::sqrt
                          (
                              (ax*ax + ay*ay + az*az) *
                              (gdYdx*gdYdx + gdYdy*gdYdy + gdYdz*gdYdz )
                           );

      if (_AFact > 1.0E-20)
        {
          _AdotDY                 =      std::min( std::fabs( gdYdx*ax + gdYdy*ay + gdYdz*az )/ (_AFact + 1.0E-20), 1.0 ) ;

          _angleWtFactor          =      std::pow(  _AdotDY, _angleFac);

          if ( _AdotDY < 0.5 )
            {
              _angleWtFactor      =       2 * _AdotDY*_AdotDY*_AdotDY - 1.36*_AdotDY*_AdotDY + 0.306 * _AdotDY - 0.0145;

              if (_angleWtFactor < 0 ) _angleWtFactor  =  0;
            }

          if (_angleWtFactor > 0.9 ) _angleWtFactor  =  0.99;
        }
    }


    double Yf  =   YuSide;

    if ( schemeOp ==  "maxgbca")
      {
        Yf  =   maxGBCAVofF(
                                                      xf,   yf,   zf
                                                  ,   ax,   ay,   az
                                                  ,   xcu,  ycu,  zcu
                                                  ,   xcd,  ycd,  zcd
                                                  ,  mdot, YuSide, YdSide
                                                  ,  dYdxu , dYdyu , dYdzu
                                                  ,  dYdxd , dYdyd , dYdzd
                                                  ,   xVelu ,  yVelu,  zVelu
                                                 );
      }


    if ( schemeOp ==  "core")
      {
        Yf  =   maxGBCAVofCore(
                                                      xf,   yf,   zf
                                                  ,   ax,   ay,   az
                                                  ,   xcu,  ycu,  zcu
                                                  ,   xcd,  ycd,  zcd
                                                  ,  mdot, YuSide, YdSide
                                                  ,  dYdxu , dYdyu , dYdzu
                                                  ,  dYdxd , dYdyd , dYdzd
                                                  ,   xVelu ,  yVelu,  zVelu
                                                 );
      }


    if ( schemeOp ==  "core-limited")
      {
        Yf  =   maxGBCAVofCoreLimited(
                                                      xf,   yf,   zf
                                                  ,   ax,   ay,   az
                                                  ,   xcu,  ycu,  zcu
                                                  ,   xcd,  ycd,  zcd
                                                  ,  mdot, YuSide, YdSide
                                                  ,  dYdxu , dYdyu , dYdzu
                                                  ,  dYdxd , dYdyd , dYdzd
                                                  ,   xVelu ,  yVelu,  zVelu
                                                 );
      }





    return Yf;
  }



private:


  double
  SISP( double &Uu, double &Up, double &Ud  )
  {
    // Simple Interpolation for Scalar Profile
    // SISP

    double phiBar_c = 0;

    if ( std::fabs(Ud - Uu) > 1.0E-8)
       {
         phiBar_c = (Up - Uu) / (Ud - Uu);
       }
    else
      {
        return Up;
      }

     // start with upwind by default
    double
    phiFluxFace_U         =       Up ;

    // phi_f               =       a*Up + b*Ud + (1-a-b)*Uu  for phibar_f =  a * phiBar_c + b

    // threeByEight    =    0.375
    // sevenByFour     =    1.75
    // threeByFour     =    0.75
    // oneByFour       =    0.25

    double a  =  1;
    double b  =  0;

    if (  (phiBar_c > 0) && (phiBar_c <  0.25 ))
      {
        a  =   1.75;
        b  =   0;
      }
    else
    if (  (phiBar_c >= 0.25) && (phiBar_c <  0.5 ))
      {
        // a  =  -2*phiBar_c + 7.0/4.0;
        // b  =   3*phiBar_c/4.0;
        a     =  -2.00*phiBar_c + 1.75;
        b     =   0.75*phiBar_c;

      }
    else
    if (  (phiBar_c >= 0.5) && (phiBar_c <=  0.75 ))
      {
        // a  =   -12*phiBar_c/5.0    +  ( 39.0/20.0 );
        // b  =    (19.0/10.0 )*phiBar_c  -  23.0/40.0 ;
        a     =    -2.4*phiBar_c  +  1.95;
        b     =     1.9*phiBar_c  -  0.575;
      }
    else
    if (  (phiBar_c > 0.75) && (phiBar_c <= 0.83 ))
      {
        a   =   1 - 1.2*phiBar_c;
        b   =       1.2*phiBar_c;

      }
    else
    if (  (phiBar_c > 0.83) && (phiBar_c <= 1 ))
      {
        a   =  0;
        b   =  1;
      }

    // QUICK
  //  a  =  3.0/4.0;
  //  b  =  3.0/8.0;

    // phiFluxFace_U    =     a * Up + b*Ud + ( 1- a - b)*Uu;
    return a * Up + b*Ud + ( 1- a - b)*Uu;

  }



  double
  maxGBCAVofCore(
               double & xf,  double & yf,  double & zf
             ,  double & ax,  double & ay,  double & az
             ,  double & xcu, double & ycu, double & zcu
             ,  double & xcd, double & ycd, double & zcd
             ,  double &mdot, double & YuSide, double & YdSide
             ,  double &dYdxu , double &dYdyu , double &dYdzu
             ,  double &dYdxd , double &dYdyd , double &dYdzd
             ,  double & xVelu , double & yVelu, double & zVelu
            )
  {

    double Yu   =     YuSide;
    double Yd   =     YdSide;

    if (  std::fabs( Yd - Yu ) < 1.0E-8 )
      {
        return Yu;
      }
    else
      {
        const double dist0   =     std::sqrt( (xf-xcu)*(xf-xcu) + (yf-ycu)*(yf-ycu) + (zf-zcu)*(zf-zcu) );
        const double dist1   =     std::sqrt( (xf-xcd)*(xf-xcd) + (yf-ycd)*(yf-ycd) + (zf-zcd)*(zf-zcd) );

        const double    dm   =     0.5*(dist0 + dist1) ;
        const double  delM   =     2.0 * dm + 1.0E-20;

        const    int  g      =     (YuSide >=  YdSide  ) ?  -1 : 1;

        double       Ys      =     YuSide   ;

        if ( Ys < 0 )  Ys = 0;
        if ( Ys > 1 )  Ys = 1;



        const double s1      =    _sharpness * (1 + g - 2.0*Ys)/g  + 1.0E-20;
        const double s2      =    _sharpness * (1 - g - 2.0*Ys)/g  + 1.0E-20;

        const double xbar    =     (0.5/_sharpness) * std::log(
                                           std::fabs(  ( std::exp(s1) -1 )/ (1 - std::exp(s2) + (1.0E-22 *s2) )  )
                                                             );

        const double xn12    =    -delM;


        double  Ymin  = (Yd < Yu) ? Yd : Yu;
        double  dYY   =  Yd - Yu;

        double xFace  =  0;

        double Yfn            =      Ymin  + g * dYY * 0.5*(  1.0 + g* std::tanh( _sharpness*(  (xFace - xn12)/delM  - xbar  )  )  );


        if (Yfn > 1.0)          {            Yfn = 1.0;          }        else if (Yfn < 0  )          {            Yfn = 0;          }

        return Yfn;
      }

    return YuSide;
  }





  double
  maxGBCAVofCoreLimited(
               double & xf,  double & yf,  double & zf
             ,  double & ax,  double & ay,  double & az
             ,  double & xcu, double & ycu, double & zcu
             ,  double & xcd, double & ycd, double & zcd
             ,  double &mdot, double & YuSide, double & YdSide
             ,  double &dYdxu , double &dYdyu , double &dYdzu
             ,  double &dYdxd , double &dYdyd , double &dYdzd
             ,  double & xVelu , double & yVelu, double & zVelu
            )
  {

    double Yu   =     YuSide;
    double Yd   =     YdSide;


    if (  std::fabs( Yd - Yu ) < 1.0E-8 )
      {
        return Yu;
      }
    else
      {

        double Ymin =     (Yu < Yd) ? Yu : Yd;
        double Ymax =     (Yu > Yd) ? Yu : Yd;

        double Yuu  =   Yd
                       -2 *
                             (
                                 dYdxu *  (xcd-xcu) +
                                 dYdyu *  (ycd-ycu) +
                                 dYdzu *  (zcd-zcu)
                             );

        if (Yuu > 1.0)    {  Yuu = 1.0;    }    else if (Yuu < 0  )     {      Yuu = 0;      }


        double Ywn3Default  =   std::max( 0.0,  std::min( SISP( Yuu, Yu, Yd  ), 1.0) );

        double Ywn3         =     Ywn3Default;

        double CLimiter  =  2;

        {
          const double dist0   =     std::sqrt( (xf-xcu)*(xf-xcu) + (yf-ycu)*(yf-ycu) + (zf-zcu)*(zf-zcu) );
          const double dist1   =     std::sqrt( (xf-xcd)*(xf-xcd) + (yf-ycd)*(yf-ycd) + (zf-zcd)*(zf-zcd) );
          const double    dm   =     0.5*(dist0 + dist1) ;
          const double  delM   =     2.0 * dm + 1.0E-20;

          const    int  g      =     (YuSide >=  YdSide  ) ?  -1 : 1;

          double       Ys      =     YuSide   ;

          if ( Ys < 0 )  Ys = 0;
          if ( Ys > 1 )  Ys = 1;



          const double s1      =    _sharpness * (1 + g - 2.0*Ys)/g  + 1.0E-20;
          const double s2      =    _sharpness * (1 - g - 2.0*Ys)/g  + 1.0E-20;

          const double xbar    =     (0.5/_sharpness) * std::log(
                                             std::fabs(  ( std::exp(s1) -1 )/ (1 - std::exp(s2) + (1.0E-22 *s2) )  )
                                                               );

          const double xn12    =    -delM;


          double  Ymin  = (Yd < Yu) ? Yd : Yu;
          double  dYY   =  Yd - Yu;

          double xFace  =  0;

          double Yfn            =      Ymin  + g * dYY * 0.5*(  1.0 + g* std::tanh( _sharpness*(  (xFace - xn12)/delM  - xbar  )  )  );

          if (Yfn > 1.0)          {            Yfn = 1.0;          }        else if (Yfn < 0  )          {            Yfn = 0;          }

          double phif           =    Yfn;

           double phiU  =     Yu;

           // it seems it is important that cds value be calculated by average.
           double phiCD =  0.5*(  YuSide + YdSide );

           CLimiter    =  ( std::fabs(phiCD - phiU) > 1.0E-15  ) ?      (phif - phiU)  /  (phiCD - phiU + 1.0E-15)        : 1;

           CLimiter   +=  0.1 ;  // a bit of compressible

           if ( CLimiter > 2.0 ) CLimiter = 2.0;
           if ( CLimiter < 0.0 ) CLimiter = 0.0;

           if ( CLimiter > 0.75 )
             {
               // making it compressible
               Yfn     =         Yu + CLimiter *  (
                                                dYdxu *  (xf - xcu) +
                                                dYdyu *  (yf - ycu) +
                                                dYdzu *  (zf - zcu)
                                                 );
             }
           else
             {
               Yfn  =   Ywn3Default;
             }

           if (Yfn < 0 ) Yfn =     0;
           if (Yfn > 1 ) Yfn =     1;

           Ywn3  =  Yfn;
        }

        if (Ywn3 > 1.0)         {           Ywn3 = 1.0;          }        else if (Ywn3 < 0  )          {            Ywn3 = 0;         }

        return  Ywn3;
      }

    return YuSide;
  }




  double
  maxGBCAVofF(
               double & xf,  double & yf,  double & zf
             ,  double & ax,  double & ay,  double & az
             ,  double & xcu, double & ycu, double & zcu
             ,  double & xcd, double & ycd, double & zcd
             ,  double &mdot, double & YuSide, double & YdSide
             ,  double &dYdxu , double &dYdyu , double &dYdzu
             ,  double &dYdxd , double &dYdyd , double &dYdzd
             ,  double & xVelu , double & yVelu, double & zVelu
            )
  {

    double Yu   =     YuSide;
    double Yd   =     YdSide;


    if (  std::fabs( Yd - Yu ) < 1.0E-8 )
      {
        return Yu;
      }
    else
      {

        double Ymin =     (Yu < Yd) ? Yu : Yd;
        double Ymax =     (Yu > Yd) ? Yu : Yd;

        double Yuu  =   Yd
                       -2 *
                             (
                                 dYdxu *  (xcd-xcu) +
                                 dYdyu *  (ycd-ycu) +
                                 dYdzu *  (zcd-zcu)
                             );

        if (Yuu > 1.0)    {  Yuu = 1.0;    }    else if (Yuu < 0  )     {      Yuu = 0;      }


        double Ywn3Default  =    std::max( 0.0,  std::min( SISP( Yuu, Yu, Yd  ), 1.0) );

        double Ywn3         =     Ywn3Default;

        double CLimiter     =    2;

        {
          const double dist0   =     std::sqrt( (xf-xcu)*(xf-xcu) + (yf-ycu)*(yf-ycu) + (zf-zcu)*(zf-zcu) );
          const double dist1   =     std::sqrt( (xf-xcd)*(xf-xcd) + (yf-ycd)*(yf-ycd) + (zf-zcd)*(zf-zcd) );
          const double    dm   =     0.5*(dist0 + dist1) ;
          const double  delM   =     2.0 * dm + 1.0E-20;

          const    int  g      =     (YuSide >=  YdSide  ) ?  -1 : 1;

          double       Ys      =     YuSide   ;

          if ( Ys < 0 )  Ys = 0;
          if ( Ys > 1 )  Ys = 1;

          const double s1      =    _sharpness * (1 + g - 2.0*Ys)/g  + 1.0E-20;
          const double s2      =    _sharpness * (1 - g - 2.0*Ys)/g  + 1.0E-20;

          const double xbar    =     (0.5/_sharpness) * std::log(
                                             std::fabs(  ( std::exp(s1) -1 )/ (1 - std::exp(s2) + (1.0E-22 *s2) )  )
                                                               );

          const double xn12    =    -delM;


          double  Ymin  = (Yd < Yu) ? Yd : Yu;
          double  dYY   =  Yd - Yu;

          double xFace  =  0;

          double Yfn            =      Ymin  + g * dYY * 0.5*(  1.0 + g* std::tanh( _sharpness*(  (xFace - xn12)/delM  - xbar  )  )  );


          if (Yfn > 1.0)          {            Yfn = 1.0;          }        else if (Yfn < 0  )          {            Yfn = 0;          }

          double phif           =    Yfn;

           // Calculate UD and CD face value
           double phiU  =     Yu;
           // it seems it is important that cds value be calculated by average.
           double phiCD =  0.5*(  YuSide + YdSide );

           CLimiter    =  ( std::fabs(phiCD - phiU) > 1.0E-15  ) ?      (phif - phiU)  /  (phiCD - phiU + 1.0E-15)        : 1;

           CLimiter   +=  0.1 ;  // a bit of compressible

           if ( CLimiter > 2.0 ) CLimiter = 2.0;
           if ( CLimiter < 0.0 ) CLimiter = 0.0;

           if ( CLimiter > 0.75 )
             {
               // making it compressible
               Yfn     =         Yu + CLimiter *  (
                                                dYdxu *  (xf - xcu) +
                                                dYdyu *  (yf - ycu) +
                                                dYdzu *  (zf - zcu)
                                                 );
             }
           else
             {
               Yfn  =   Ywn3Default;
             }

           if (Yfn < 0 ) Yfn =     0;
           if (Yfn > 1 ) Yfn =     1;

           Ywn3  =  Yfn;
        }

        return  _angleWtFactor*Ywn3 +  (1-_angleWtFactor)*Ywn3Default;;
      }

    return YuSide;
  }



};

#endif
