
#include "ZalesakDisc.h"

ZalesakDisc::
ZalesakDisc()
: BaseSolver()
{

}

ZalesakDisc::
~ZalesakDisc()
{

}

void
ZalesakDisc::
initialize(double u0, double v0)
{

  double  radius  =  0.2;
  double      x0  =  0.5;
  double      y0  =  0.75;


  int nbcells  =  _region._ncellsBnd;


  _alphaInit.resize(  nbcells  );
  _alpha1.resize(  nbcells  );


  _alpha0.resize(  nbcells  );
  _alpha1.resize(  nbcells  );

  _alpha01.resize(  nbcells  );
  _alpha11.resize(  nbcells  );

  _alpha02.resize(  nbcells  );
  _alpha12.resize(  nbcells  );

  _xvel.resize(  nbcells  );
  _yvel.resize(  nbcells  );
  _zvel.resize(  nbcells  );


  _dAlphadx0.resize(  nbcells  );
  _dAlphady0.resize(  nbcells  );
  _dAlphadz0.resize(  nbcells  );

  _dAlphadx1.resize(  nbcells  );
  _dAlphady1.resize(  nbcells  );
  _dAlphadz1.resize(  nbcells  );


  _alpha0Min.resize(  nbcells  );
  _alpha0Max.resize(  nbcells  );


  _Ap .resize(  nbcells  );
  _Src.resize(  nbcells  );

  double xmin = 0.475;
  double xmax = 0.525;

  double ymin = -1;
  double ymax = 0.85;

  double rd2  =  radius*radius;

  for  (int c = 0; c < nbcells; c++ )
    {
      _alpha0[c]        =      0;
      _alpha1[c]        =      1 - _alpha0[c];

      double dist2      =      ( _region._xc[c] - x0 ) * ( _region._xc[c] - x0 ) + ( _region._yc[c] - y0 ) * ( _region._yc[c] - y0 );

      if ( dist2 <= rd2 )
        {
          _alpha0[c]    =      1;
          _alpha1[c]    =      1 - _alpha0[c];
        }


      if (  (_region._xc[c] >=  xmin)  &&  (_region._xc[c] <=  xmax)  &&  (_region._yc[c] >=  ymin) && ( _region._yc[c] <=  ymax ) )
        {
          _alpha0[c]    =    0;
          _alpha1[c]    =    1 - _alpha0[c];
        }

      _alphaInit[c]     =    _alpha0[c];
      _xvel[c]          =     _region._yc[c] - 0.5;
      _yvel[c]          =   -(_region._xc[c] - 0.5  );
      _zvel[c]          =      0;
    }

  // takes a single step of VOF solver
  memcpy(  _alpha01.data(), _alpha0.data(), sizeof(double) * _alpha0.size()  );
  memcpy(  _alpha11.data(), _alpha1.data(), sizeof(double) * _alpha1.size()  );

  memcpy(  _alpha02.data(), _alpha01.data(), sizeof(double) * _alpha0.size()  );
  memcpy(  _alpha12.data(), _alpha11.data(), sizeof(double) * _alpha1.size()  );

}

void
ZalesakDisc::
applyBC()
{}
