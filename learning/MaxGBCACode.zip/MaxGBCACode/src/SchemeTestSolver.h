#ifndef SRC_SCHEMETESTSOLVER_H_
#define SRC_SCHEMETESTSOLVER_H_

#include "BaseSolver.h"


class SchemeTestSolver  :   public BaseSolver
{
public:
           SchemeTestSolver();
  virtual ~SchemeTestSolver();

  void     initialize    (double u0, double v0);
  void     applyBC       (   );

};

#endif
