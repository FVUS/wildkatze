To compile 

cd build
cmake ../
make 



Calculate
Set Up Input File


3
problem               disc-advection             
 (or zalesak-disc)
convection-scheme     Core-limited
 (or any of HRIC    CICSAM    Core   Core-limited  MaxGBCA)
time-scheme           TwoLevel  
(or Euler)
5
 courant             0.2
 max-time            4    
(final stopping time)
 inner-iterations    8 
 disc-advection-x-velocity      1.0
 disc-advection-y-velocity      0.0
(Dir disc-advection case this will be the velocity field. For Zalesak’s problem this will be ignored)


To run 
./maxgbca

This shall produce a vtk file that could be viewed in Paraview. 

To develop the code further

The class BaseSolver creates a 2D region (NxM) and also performs the calculation. Your class shall then provide the boundary conditions and update the velocities if they are time dependent. See the three examples present in the code.
